for(let i = 0; i < hight; i++){
    rightBoundaries.push(i * width);
}
for(let i = 1; i <= hight; i++){
    leftBoundaries.push(i * width - 1);
}