// Selecting elements with class names and IDs using querySelector
const bigContainer= document.querySelector(".bigContainer");
const infoTable= document.querySelector(".infoTable");
const player1Elem= document.querySelector(".player1");
const player2Elem= document.querySelector(".player2");
const board= document.querySelector(".board");
const timerElem= document.querySelector(".timerElem");
const tablePlayer1= document.querySelector(".tablePlayer1");
const tablePlayer2= document.querySelector(".tablePlayer2");
const tablePlayer1Corr= document.querySelector(".tablePlayer1Corr");
const tablePlayer2Corr= document.querySelector(".tablePlayer2Corr");
const tablePlayer1Win= document.querySelector(".tablePlayer1Win");
const tablePlayer2Win= document.querySelector(".tablePlayer2Win");
const player1Name= document.querySelector('input[name="player1"]');
const player2Name= document.querySelector('input[name="player2"]');
const submitBtn= document.querySelector(".submit");
const popupWrapper= document.querySelector(".popupWrapper");
const select= document.querySelector("#card-option");